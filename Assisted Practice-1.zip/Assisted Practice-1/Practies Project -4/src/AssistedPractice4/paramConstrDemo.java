package AssistedPractice4;

public class paramConstrDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Std std1=new Std(2,"Alex");
		Std std2=new Std(10,"Annie");
		std1.display();
		std2.display();

	}

}
