package AssistedPractice2;

public class defAccessSpecifier {

}
