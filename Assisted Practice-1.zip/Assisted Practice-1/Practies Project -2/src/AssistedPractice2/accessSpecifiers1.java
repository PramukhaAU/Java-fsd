package AssistedPractice2;

class vijay
{ 
  void display() 
     { 
         System.out.println("You are using defalut access specifier"); 
     } 
} 



public class accessSpecifiers1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Dafault Access Specifier");
		vijay obj = new vijay(); 		  
        obj.display(); 


	}

}
