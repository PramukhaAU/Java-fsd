package AssistedPractice22;
import AssistedPractice2.proaccessspecifiers;


public class accessSpecifiers3 extends proaccessspecifiers {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		accessSpecifiers3 obj = new accessSpecifiers3 ();   
	       obj.display();  


	}

}
