import { Component } from "@angular/core";

@Component({
     selector: "Product List",
     templateUrl:'./product-list.component.html'
})

export class ProductListComponent{
    pageTitle: string = "Product List Page"
}