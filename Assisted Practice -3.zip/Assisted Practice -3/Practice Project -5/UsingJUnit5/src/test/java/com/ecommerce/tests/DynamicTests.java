package com.ecommerce.tests;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.function.Executable;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

@DisplayName("JUnit 5 Dynamic Tests Example")
public class DynamicTests {

    @TestFactory
    Collection<DynamicTest> dynamicTests() {
        return Arrays.asList(
            dynamicTest("simple dynamic test", () -> assertTrue(true)),
            dynamicTest("My Executable Class", new MyExecutable()),
            dynamicTest("Exception Executable", () -> { throw new Exception("Exception Example"); }),
            dynamicTest("simple dynamic test-2", () -> assertTrue(true))
        );
    }

    private DynamicTest dynamicTest(String displayName, Executable executable) {
        return DynamicTest.dynamicTest(displayName, executable);
    }

    static class MyExecutable implements Executable {
        @Override
        public void execute() throws Throwable {
        	System.out.println("Hello World!");
        }
    }
}
