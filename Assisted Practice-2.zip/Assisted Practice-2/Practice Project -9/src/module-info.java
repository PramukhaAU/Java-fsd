/**
 * 
 */
/**
 * 
 */
module DiamondProblem {
}