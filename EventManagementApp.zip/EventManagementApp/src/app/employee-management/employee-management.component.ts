import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-management',
  templateUrl: './employee-management.component.html',
  styleUrls: ['./employee-management.component.css'],
})
export class EmployeeManagementComponent implements OnInit {
  employee: any = { id: null, first_name: '', last_name: '', email: '' };
  employees: any[] = [];
  isEditing: boolean = false;
  selectedEmployeeId: number | null = null;

  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void {
    // Fetch employees from the service when the component is initialized
    this.employeeService.getEmployees().subscribe((data) => {
      this.employees = data;
    });
  }

  submitForm(): void {
    if (this.isEditing) {
      // Update existing employee
      this.employeeService.updateEmployee(this.employee).subscribe((updatedEmployee) => {
        // Handle the updated employee
        console.log('Employee updated:', updatedEmployee);
        this.resetForm();
      });
    } else {
      // Add new employee
      this.employeeService.addEmployee(this.employee).subscribe((newEmployee) => {
        // Handle the newly added employee
        console.log('Employee added:', newEmployee);
        this.resetForm();
      });
    }
  }

  deleteEmployee(): void {
    if (this.selectedEmployeeId !== null) {
      // Delete selected employee
      this.employeeService.deleteEmployee(this.selectedEmployeeId).subscribe(() => {
        // Handle the deleted employee
        console.log('Employee deleted:', this.selectedEmployeeId);
        this.resetForm();
      });
    }
  }

  resetForm(): void {
    // Reset the form fields and flags
    this.employee = { id: null, first_name: '', last_name: '', email: '' };
    this.isEditing = false;
    this.selectedEmployeeId = null;
  }
}
