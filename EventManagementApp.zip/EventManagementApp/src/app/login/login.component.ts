import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = ''; // Declare the errorMessage property here

  constructor(private router: Router) {}

  // Function to handle the login process
  login(): void {
    // In a real application, you would send a request to a backend service for authentication.
    // For simplicity, I'll use a hard-coded username and password here.
    const hardcodedUsername: string = 'admin';
    const hardcodedPassword: string = 'password';

    if (this.username === hardcodedUsername && this.password === hardcodedPassword) {
      // Navigate to the employee list page on successful login
      this.router.navigate(['/employee-list']);
    } else {
      // Display an error message for unsuccessful login
      this.errorMessage = 'Invalid username or password';
    }
  }
}
