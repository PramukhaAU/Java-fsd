
import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service'; 

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
  employees: any[]= []; 

  constructor(private employeeService: EmployeeService) { }

  ngOnInit(): void {
  
    this.employeeService.getEmployees().subscribe(
      (data) => {
        this.employees = data;
      },
      (error) => {
        console.error('Error fetching employees: ', error);
      }
    );
  }

  deleteEmployee(employeeId: number): void {
    // Call the service to delete the employee
    this.employeeService.deleteEmployee(employeeId).subscribe(
      () => {
        // Update the employees list after deletion
        this.employees = this.employees.filter(emp => emp.id !== employeeId);
      },
      (error) => {
        console.error('Error deleting employee: ', error);
      }
    );
  }
}
