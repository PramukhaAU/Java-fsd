/**
 * 
 */
/**
 * 
 */
module RangeQueries {
}