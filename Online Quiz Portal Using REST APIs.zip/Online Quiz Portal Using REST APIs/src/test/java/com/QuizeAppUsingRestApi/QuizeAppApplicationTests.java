package com.QuizeAppUsingRestApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
