package com.QuizeAppUsingRestApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizeAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizeAppApplication.class, args);
		System.out.println("Quize App.....");
	}

}
