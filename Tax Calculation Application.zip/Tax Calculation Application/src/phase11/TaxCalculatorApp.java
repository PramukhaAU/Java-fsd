package phase11;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Property {
    private int id;
    private double baseValue;
    private double builtUpArea;
    private int age;
    private boolean inCity;
    private double tax;
    
	public Property(int id, double baseValue, double builtUpArea, int age, boolean inCity, double tax) {
		super();
		this.id = id;
		this.baseValue = baseValue;
		this.builtUpArea = builtUpArea;
		this.age = age;
		this.inCity = inCity;
		this.tax = tax;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getBaseValue() {
		return baseValue;
	}

	public void setBaseValue(double baseValue) {
		this.baseValue = baseValue;
	}

	public double getBuiltUpArea() {
		return builtUpArea;
	}

	public void setBuiltUpArea(double builtUpArea) {
		this.builtUpArea = builtUpArea;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean isInCity() {
		return inCity;
	}

	public void setInCity(boolean inCity) {
		this.inCity = inCity;
	}

	public double getTax() {
		return tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

    // Constructor, getters, and setters for Property class
}

class Vehicle {
    private int id;
    private String brand;
    private String regNumber;
    private double maxVelocity;
    private int capacity;
    private int vehicleType; // 1 for Petrol, 2 for Diesel, 3 for CNG/LPG
    private double purchaseCost;
    private double tax;
    
	public Vehicle(int id, String brand, String regNumber, double maxVelocity, int capacity, int vehicleType,
			double purchaseCost, double tax) {
		super();
		this.id = id;
		this.brand = brand;
		this.regNumber = regNumber;
		this.maxVelocity = maxVelocity;
		this.capacity = capacity;
		this.vehicleType = vehicleType;
		this.purchaseCost = purchaseCost;
		this.tax = tax;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getRegNumber() {
		return regNumber;
	}

	public void setRegNumber(String regNumber) {
		this.regNumber = regNumber;
	}

	public double getMaxVelocity() {
		return maxVelocity;
	}

	public void setMaxVelocity(double maxVelocity) {
		this.maxVelocity = maxVelocity;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public int getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(int vehicleType) {
		this.vehicleType = vehicleType;
	}

	public double getPurchaseCost() {
		return purchaseCost;
	}

	public void setPurchaseCost(double purchaseCost) {
		this.purchaseCost = purchaseCost;
	}

	public double getTax() {
		return tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}
    
    
    // Constructor, getters, and setters for Vehicle class
}

public class TaxCalculatorApp {
    private static List<Property> properties = new ArrayList<>();
    private static List<Vehicle> vehicles = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        showWelcomeScreen();

        int choice;
        do {
            choice = getMenuChoice();
            switch (choice) {
                case 1:
                    addProperty();
                    break;
                case 2:
                    addVehicle();
                    break;
                case 3:
                    displayAll();
                    break;
                case 4:
                    System.out.println("Thank you for using Tax Calculator App. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);
    }

    private static void showWelcomeScreen() {
        // Display the welcome screen with application details
    	System.out.println("===================================");
        System.out.println("  WELCOME TO TAX CALCULATION APP");
        System.out.println("===================================");
        System.out.println("  PLEASE LOGIN TO CONTINUE");
        System.out.println("-----------------------------------");
        System.out.println("  USERNAME: admin");
        System.out.println("  PASSWORD: admin123");
        System.out.println("===================================");
        System.out.println("  MENU OPTIONS:");
        System.out.println("  1. Add Property");
        System.out.println("  2. Add Vehicle");
        System.out.println("  3. Display All");
        System.out.println("  4. Exit");
        System.out.println("===================================");
        System.out.print("Enter your choice: ");
    }

    private static int getMenuChoice() {
    
    	    System.out.println("\n===================================");
    	    System.out.println("          MAIN MENU");
    	    System.out.println("===================================");
    	    System.out.println("  1. Add Property");
    	    System.out.println("  2. Add Vehicle");
    	    System.out.println("  3. Display All");
    	    System.out.println("  4. Exit");
    	    System.out.println("===================================");

    	    System.out.print("Enter your choice (1-4): ");
    	    
    	    int choice;
    	    while (true) {
    	        try {
    	            choice = scanner.nextInt();
    	            if (choice >= 1 && choice <= 4) {
    	                break; // Valid choice
    	            } else {
    	                System.out.print("Invalid choice. Enter a number between 1 and 4: ");
    	            }
    	        } catch (java.util.InputMismatchException e) {
    	            System.out.print("Invalid input. Enter a valid number between 1 and 4: ");
    	            scanner.next(); // Clear the invalid input
    	        }
    	    }
    	    
    	    return choice;
    }

    private static void addProperty() {
        // Add property details and calculate property tax
        // Validate input as per the provided requirements
        // Store the property in the 'properties' list
    	System.out.println("===================================");
        System.out.println("      ADD PROPERTY DETAILS");
        System.out.println("===================================");

        // Create a new Property object
        Property property = new Property(0, 0, 0, 0, false, 0);

        // Input property details
        System.out.print("Enter the base value of the land: ");
        property.setBaseValue(scanner.nextDouble());

        System.out.print("Enter the built-up area of the land: ");
        property.setBuiltUpArea(scanner.nextDouble());

        System.out.print("Enter the age of the land in years: ");
        property.setAge(scanner.nextInt());

        System.out.print("Is the land located in the city? (Y/N): ");
        String inCityInput = scanner.next().toLowerCase();
        property.setInCity(inCityInput.equals("y"));

        // Calculate property tax
        double tax = 0.0;
        if (property.isInCity()) {
            tax = (property.getBuiltUpArea() * property.getAge() * property.getBaseValue()) +
                  (0.5 * property.getBuiltUpArea());
        } else {
            tax = property.getBuiltUpArea() * property.getAge() * property.getBaseValue();
        }
        property.setTax(tax);

        // Display calculated property tax
        System.out.println("Property tax for this property is: " + property.getTax());

        // Store the property in the 'properties' list
        properties.add(property);

        System.out.println("Property details added successfully!");
        
        System.out.println("\n1. ADD PROPERTY DETAILS");
        System.out.println("2. CALCULATE PROPERTY TAX");
        System.out.println("3. DISPLAY ALL PROPERTIES");
        System.out.println("4. BACK TO MAIN MENU");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                addProperty();
                break;
            case 2:
                calculatePropertyTax(); // You can implement this method for tax calculation
                break;
            case 3:
                displayAllProperties(); // You can implement this method to display properties
                break;
            case 4:
                // User chose to go back to the main menu, no action needed
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private static void displayAllProperties() {
        System.out.println("===================================");
        System.out.println("   DISPLAY ALL PROPERTIES");
        System.out.println("===================================");

        // Check if there are properties to display
        if (properties.isEmpty()) {
            System.out.println("No properties added yet.");
            return;
        }

        // Display a list of properties
        System.out.println("List of Properties:");
        for (int i = 0; i < properties.size(); i++) {
            Property property = properties.get(i);
            System.out.println("Property ID:" + property.getId());
            System.out.println("Base Value of Land:" + property.getBaseValue());
            System.out.println("Built-Up Area: " + property.getBuiltUpArea());
            System.out.println("Age of Land (Years): " + property.getAge());
            System.out.println("Located in City: " + (property.isInCity() ? "Yes" : "No"));
            System.out.println("Property Tax: " + property.getTax());
            System.out.println("-------------------------------");
        }
    }

    private static void calculatePropertyTax() {
        System.out.println("===================================");
        System.out.println("   CALCULATE PROPERTY TAX");
        System.out.println("===================================");

        // Check if there are properties to calculate tax for
        if (properties.isEmpty()) {
            System.out.println("No properties added yet.");
            return;
        }

        // Display a list of properties
        System.out.println("List of Properties:");
        for (int i = 0; i < properties.size(); i++) {
            Property property = properties.get(i);
            System.out.println("Property ID: " + property.getId());
            System.out.println("Base Value of Land: " + property.getBaseValue());
            System.out.println("Built-Up Area: " + property.getBuiltUpArea());
            System.out.println("Age of Land (Years): " + property.getAge());
            System.out.println("Located in City: " + (property.isInCity() ? "Yes" : "No"));
            System.out.println("-------------------------------");
        }

        // Input property ID to calculate tax for
        System.out.print("Enter the Property ID to calculate tax: ");
        int propertyIdToCalculateTax = scanner.nextInt();

        // Find the property with the specified ID
        Property selectedProperty = null;
        for (Property property : properties) {
            if (property.getId() == propertyIdToCalculateTax) {
                selectedProperty = property;
                break;
            }
        }

        // Calculate property tax for the selected property
        if (selectedProperty != null) {
            double tax = 0.0;
            if (selectedProperty.isInCity()) {
                tax = (selectedProperty.getBuiltUpArea() * selectedProperty.getAge() * selectedProperty.getBaseValue())
                        + (0.5 * selectedProperty.getBuiltUpArea());
            } else {
                tax = selectedProperty.getBuiltUpArea() * selectedProperty.getAge() * selectedProperty.getBaseValue();
            }
            selectedProperty.setTax(tax);

            // Display calculated property tax
            System.out.println("Property tax for Property ID " + selectedProperty.getId() + " is: " + selectedProperty.getTax());
        } else {
            System.out.println("Property with ID " + propertyIdToCalculateTax + " not found.");
        }
    }

	private static void addVehicle() {
        // Add vehicle details and calculate vehicle tax
        // Validate input as per the provided requirements
        // Store the vehicle in the 'vehicles' list
    	System.out.println("===================================");
        System.out.println("       ADD VEHICLE DETAILS");
        System.out.println("===================================");

        // Create a new Vehicle object
        Vehicle vehicle = new Vehicle(0, null, null, 0, 0, 0, 0, 0);

        // Input vehicle details
        System.out.print("Enter the brand of the vehicle: ");
        vehicle.setBrand(scanner.next());

        System.out.print("Enter the registration number (4 digits): ");
        vehicle.setRegNumber(scanner.next());

        System.out.print("Enter the maximum velocity of the vehicle (KMPH): ");
        vehicle.setMaxVelocity(scanner.nextDouble());

        System.out.print("Enter the capacity (number of seats) of the vehicle: ");
        vehicle.setCapacity(scanner.nextInt());

        System.out.println("Choose the type of the vehicle:");
        System.out.println("1. Petrol Driven");
        System.out.println("2. Diesel Driven");
        System.out.println("3. CNG/LPG Driven");
        System.out.print("Enter the type (1/2/3): ");
        vehicle.setVehicleType(scanner.nextInt());

        System.out.print("Enter the purchase cost of the vehicle: ");
        vehicle.setPurchaseCost(scanner.nextDouble());

        // Calculate vehicle tax based on vehicle type
        double tax = 0.0;
        switch (vehicle.getVehicleType()) {
            case 1: // Petrol Driven
                tax = vehicle.getMaxVelocity() + vehicle.getCapacity() + (0.10 * vehicle.getPurchaseCost());
                break;
            case 2: // Diesel Driven
                tax = vehicle.getMaxVelocity() + vehicle.getCapacity() + (0.11 * vehicle.getPurchaseCost());
                break;
            case 3: // CNG/LPG Driven
                tax = vehicle.getMaxVelocity() + vehicle.getCapacity() + (0.12 * vehicle.getPurchaseCost());
                break;
            default:
                System.out.println("Invalid vehicle type.");
                return;
        }
        vehicle.setTax(tax);

        // Display calculated vehicle tax
        System.out.println("Vehicle tax for this vehicle is: " + vehicle.getTax());

        // Store the vehicle in the 'vehicles' list
        vehicles.add(vehicle);

        System.out.println("Vehicle details added successfully!");
        
        System.out.println("\n1. ADD VEHICLE DETAILS");
        System.out.println("2. CALCULATE VEHICLE TAX");
        System.out.println("3. DISPLAY ALL VEHICLES");
        System.out.println("4. BACK TO MAIN MENU");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                addVehicle();
                break;
            case 2:
                calculateVehicleTax(); // You can implement this method for tax calculation
                break;
            case 3:
                displayAllVehicles(); // You can implement this method to display vehicles
                break;
            case 4:
                // User chose to go back to the main menu, no action needed
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

	private static void calculateVehicleTax() {
	    System.out.println("===================================");
	    System.out.println("   CALCULATE VEHICLE TAX");
	    System.out.println("===================================");

	    // Check if there are vehicles to calculate tax for
	    if (vehicles.isEmpty()) {
	        System.out.println("No vehicles added yet.");
	        return;
	    }

	    // Display a list of vehicles
	    System.out.println("List of Vehicles:");
	    for (int i = 0; i < vehicles.size(); i++) {
	        Vehicle vehicle = vehicles.get(i);
	        System.out.println("Vehicle ID: " + vehicle.getId());
	        System.out.println("Brand: " + vehicle.getBrand());
	        System.out.println("Registration Number: " + vehicle.getRegNumber());
	        System.out.println("Maximum Velocity (KMPH): " + vehicle.getMaxVelocity());
	        System.out.println("Capacity (Number of Seats): " + vehicle.getCapacity());
	        System.out.println("Vehicle Type: " + getVehicleTypeText(vehicle.getVehicleType()));
	        System.out.println("Purchase Cost: " + vehicle.getPurchaseCost());
	        System.out.println("Vehicle Tax: " + vehicle.getTax());
	        System.out.println("-------------------------------");
	    }

	    // Input vehicle ID to calculate tax for
	    System.out.print("Enter the Vehicle ID to calculate tax: ");
	    int vehicleIdToCalculateTax = scanner.nextInt();

	    // Find the vehicle with the specified ID
	    Vehicle selectedVehicle = null;
	    for (Vehicle vehicle : vehicles) {
	        if (vehicle.getId() == vehicleIdToCalculateTax) {
	            selectedVehicle = vehicle;
	            break;
	        }
	    }

	    // Calculate vehicle tax for the selected vehicle
	    if (selectedVehicle != null) {
	        double tax = 0.0;
	        switch (selectedVehicle.getVehicleType()) {
	            case 1: // Petrol Driven
	                tax = selectedVehicle.getMaxVelocity() + selectedVehicle.getCapacity() + (0.10 * selectedVehicle.getPurchaseCost());
	                break;
	            case 2: // Diesel Driven
	                tax = selectedVehicle.getMaxVelocity() + selectedVehicle.getCapacity() + (0.11 * selectedVehicle.getPurchaseCost());
	                break;
	            case 3: // CNG/LPG Driven
	                tax = selectedVehicle.getMaxVelocity() + selectedVehicle.getCapacity() + (0.12 * selectedVehicle.getPurchaseCost());
	                break;
	            default:
	                System.out.println("Invalid vehicle type.");
	                return;
	        }
	        selectedVehicle.setTax(tax);

	        // Display calculated vehicle tax
	        System.out.println("Vehicle tax for Vehicle ID " + selectedVehicle.getId() + " is: " + selectedVehicle.getTax());
	    } else {
	        System.out.println("Vehicle with ID " + vehicleIdToCalculateTax + " not found.");
	    }
	}

	// Helper method to get the vehicle type as text
	private static String getVehicleTypeText(int vehicleType) {
	    switch (vehicleType) {
	        case 1:
	            return "Petrol Driven";
	        case 2:
	            return "Diesel Driven";
	        case 3:
	            return "CNG/LPG Driven";
	        default:
	            return "Unknown";
	    }
	}


	private static void displayAllVehicles() {
	    System.out.println("===================================");
	    System.out.println("   DISPLAY ALL VEHICLES");
	    System.out.println("===================================");

	    // Check if there are vehicles to display
	    if (vehicles.isEmpty()) {
	        System.out.println("No vehicles added yet.");
	        return;
	    }

	    // Display a list of vehicles
	    System.out.println("List of Vehicles:");
	    for (int i = 0; i < vehicles.size(); i++) {
	        Vehicle vehicle = vehicles.get(i);
	        System.out.println("Vehicle ID: " + vehicle.getId());
	        System.out.println("Brand: " + vehicle.getBrand());
	        System.out.println("Registration Number: " + vehicle.getRegNumber());
	        System.out.println("Maximum Velocity (KMPH): " + vehicle.getMaxVelocity());
	        System.out.println("Capacity (Number of Seats): " + vehicle.getCapacity());
	        System.out.println("Vehicle Type: " + getVehicleTypeText(vehicle.getVehicleType()));
	        System.out.println("Purchase Cost: " + vehicle.getPurchaseCost());
	        System.out.println("Vehicle Tax: " + vehicle.getTax());
	        System.out.println("-------------------------------");
	    }
	}

	private static void displayAll() {
        System.out.println("===================================");
        System.out.println("        DISPLAY ALL DETAILS");
        System.out.println("===================================");

        // Display properties
        System.out.println("Properties:");
        if (properties.isEmpty()) {
            System.out.println("No properties added yet.");
        } else {
            for (Property property : properties) {
                System.out.println("Property ID: " + property.getId());
                System.out.println("Base Value of Land: " + property.getBaseValue());
                System.out.println("Built-Up Area: " + property.getBuiltUpArea());
                System.out.println("Age of Land (Years): " + property.getAge());
                System.out.println("Located in City: " + (property.isInCity() ? "Yes" : "No"));
                System.out.println("Property Tax: " + property.getTax());
                System.out.println("-------------------------------");
            }
        }

        // Display vehicles
        System.out.println("Vehicles:");
        if (vehicles.isEmpty()) {
            System.out.println("No vehicles added yet.");
        } else {
            for (Vehicle vehicle : vehicles) {
                System.out.println("Registration Number: " + vehicle.getRegNumber());
                System.out.println("Brand: " + vehicle.getBrand());
                System.out.println("Maximum Velocity: " + vehicle.getMaxVelocity());
                System.out.println("Capacity (Number of Seats): " + vehicle.getCapacity());
                System.out.println("Vehicle Type: " + getVehicleTypeString(vehicle.getVehicleType()));
                System.out.println("Purchase Cost: " + vehicle.getPurchaseCost());
                System.out.println("Vehicle Tax: " + vehicle.getTax());
                System.out.println("-------------------------------");
            }
        }

        // Calculate and display the total tax amount
        double totalPropertyTax = properties.stream().mapToDouble(Property::getTax).sum();
        double totalVehicleTax = vehicles.stream().mapToDouble(Vehicle::getTax).sum();
        double totalTax = totalPropertyTax + totalVehicleTax;

        System.out.println("Total Property Tax: " + totalPropertyTax);
        System.out.println("Total Vehicle Tax: " + totalVehicleTax);
        System.out.println("Total Tax Amount: " + totalTax);
    }

    // Helper method to get vehicle type as a string
    private static String getVehicleTypeString(int vehicleType) {
        switch (vehicleType) {
            case 1:
                return "Petrol Driven";
            case 2:
                return "Diesel Driven";
            case 3:
                return "CNG/LPG Driven";
            default:
                return "Unknown";
        }
    }

}