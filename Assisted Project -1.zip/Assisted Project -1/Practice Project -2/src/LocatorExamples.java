import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocatorExamples {

    public static void main(String[] args) {
        // Step 1.2.1: Using ID as a Locator
        WebDriver driver = new ChromeDriver();
        driver.get("your_website_url");
        driver.findElement(By.id("Email")).sendKeys("your_email");

        // Step 1.2.2: Using class name as a Locator
        driver.findElement(By.className("classname")).click();

        // Step 1.2.3: Using Name as a Locator
        driver.findElement(By.name("name")).sendKeys("your_name");

        // Step 1.2.4: Using LinkText as a Locator
        driver.findElement(By.partialLinkText("plink")).click();

        // Step 1.2.5: Using Xpath as a Locator
        // a. Relative Xpath
        driver.findElement(By.xpath("//*[@class='relativexapath']")).click();
        // b. Absolute Xpath
        driver.findElement(By.xpath("html/body/div[1]/div[1]/div/h4[1]/b")).click();

        // Step 1.2.6: Using CSS Selector as a Locator
        // a. Tag and ID
        driver.findElement(By.cssSelector("input#email")).sendKeys("your_email");
        // b. Tag and Class
        driver.findElement(By.cssSelector("input.inputtext")).sendKeys("your_text");
        // c. Tag and Attribute
        driver.findElement(By.cssSelector("input[name=lastName]")).sendKeys("your_lastname");
        // d. Tag, Class, and Attribute
        driver.findElement(By.cssSelector("input.inputtext[tabindex=1]")).sendKeys("your_text");
        // e. Inner text
        driver.findElement(By.cssSelector("font:contains('Boston')")).click();

        // Step 1.2.7: Using Xpath Handling complex and Dynamic elements
        // a. Contains()
        driver.findElement(By.xpath("//*[contains(text(),'sub')]")).click();
        // b. Using OR & AND
        driver.findElement(By.xpath("//*[@type='submit' or @name='btnReset']")).click();
        // c. Start-with function
        driver.findElement(By.xpath("//label[starts-with(@id,'message')]")).click();
        // d. Text()
        driver.findElement(By.xpath("//td[text()='UserID']")).click();
        // e. Following
        driver.findElement(By.xpath("//*[@type='text']//following::input")).click();
        // f. Preceding
        driver.findElement(By.xpath("//*[@type='text']//preceding::input")).click();
        // g. Following - sibling
        driver.findElement(By.xpath("//*[@type='submit']//preceding::input")).click();

        

        // Close the browser
        driver.quit();
    }
}
