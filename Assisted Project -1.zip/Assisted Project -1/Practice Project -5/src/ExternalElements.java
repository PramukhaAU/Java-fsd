import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExternalElements {

    public static void main(String[] args) {
        // Set the path to your ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "\"C:\\\\Mphasis FSD\\\\1.Phase -5\\\\chromedriver-win64\\\\chromedriver-win64\\\\chromedriver.exe\"");

        // Initialize the ChromeDriver
        WebDriver driver = new ChromeDriver();

        try {
            // Step 1.5.1: Handling External pop ups
            driver.get("https://www.example.com");

            // Click on a button to trigger a pop-up
            driver.findElement(By.id("popupButton")).click();

            // Switch to the alert and click on 'OK'
            driver.switchTo().alert().accept();

            // Alternatively, to click on 'Cancel'
            // driver.switchTo().alert().dismiss();

            // To capture the alert message
            String alertMessage = driver.switchTo().alert().getText();
            System.out.println("Alert Message: " + alertMessage);

            // To enter information in the alert
            // driver.switchTo().alert().sendKeys("Text");

            // To exit from the popup
            // driver.switchTo().alert().dismiss();

            // Step 1.5.2: Handling new Tabs and new Window
            // Opening a new tab
            driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");

            // Opening a new window
            driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "n");

            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
