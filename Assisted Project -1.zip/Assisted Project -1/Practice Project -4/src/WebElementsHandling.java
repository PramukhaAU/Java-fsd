import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class WebElementsHandling {

    public static void main(String[] args) {
        // Set the path to your ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\Mphasis FSD\\1.Phase -5\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");

        // Initialize the ChromeDriver
        WebDriver driver = new ChromeDriver();

        try {
            // Step 1.4.1: Edit box
            driver.get("https://example.com");
            WebElement editBox = driver.findElement(By.id("editBoxId"));
            
            // Enter a Value
            editBox.sendKeys("Hello, World!");

            // Clear the Value
            editBox.clear();

            // Check enabled status
            boolean isEditBoxEnabled = editBox.isEnabled();
            System.out.println("Edit Box Enabled: " + isEditBoxEnabled);

            // Check edit box existence
            boolean isEditBoxPresent = driver.findElements(By.id("editBoxId")).size() > 0;
            System.out.println("Edit Box Present: " + isEditBoxPresent);

            // Get the value
            String editBoxValue = editBox.getAttribute("value");
            System.out.println("Edit Box Value: " + editBoxValue);

            // Step 1.4.2: Link
            WebElement link = driver.findElement(By.linkText("Example Link"));

            // Click Link
            link.click();

            // Check the link existence
            boolean isLinkPresent = driver.findElements(By.linkText("Example Link")).size() > 0;
            System.out.println("Link Present: " + isLinkPresent);

            // Check the link enabled status
            boolean isLinkEnabled = link.isEnabled();
            System.out.println("Link Enabled: " + isLinkEnabled);

            // Return the Link Name
            String linkName = link.getText();
            System.out.println("Link Name: " + linkName);

            // Step 1.4.3: Button
            WebElement button = driver.findElement(By.id("submitButtonId"));

            // Click Button
            button.click();

            // Check Enabled status
            boolean isButtonEnabled = button.isEnabled();
            System.out.println("Button Enabled: " + isButtonEnabled);

            // Display status
            boolean isButtonDisplayed = button.isDisplayed();
            System.out.println("Button Displayed: " + isButtonDisplayed);

            // Step 1.4.4: Image, image link, an image button
            WebElement image = driver.findElement(By.id("imageId"));

            // Operations on Image (e.g., click)
            image.click();

            // Additional operations on image link or image button as needed

            // Step 1.4.5: Text area
            WebElement textArea = driver.findElement(By.id("textAreaId"));

            // Return / Capture Text Area or Error message from a web page
            String textAreaContent = textArea.getText();
            System.out.println("Text Area Content: " + textAreaContent);

            // Step 1.4.6: Checkbox
            WebElement checkbox = driver.findElement(By.id("checkboxId"));

            // Check if the check box is displayed or not?
            boolean isCheckboxDisplayed = checkbox.isDisplayed();
            System.out.println("Checkbox Displayed: " + isCheckboxDisplayed);

            // Check if the check box is enabled or not?
            boolean isCheckboxEnabled = checkbox.isEnabled();
            System.out.println("Checkbox Enabled: " + isCheckboxEnabled);

            // Check if the check box is Selected or not?
            boolean isCheckboxSelected = checkbox.isSelected();
            System.out.println("Checkbox Selected: " + isCheckboxSelected);

            // Select the Check box
            checkbox.click();

            // Unselect the Check box
            checkbox.click();

            // Step 1.4.7: Radio button
            WebElement radioButton = driver.findElement(By.id("radioButtonId"));

            // Select Radio Button
            radioButton.click();

            // Verify if the Radio Button is Displayed or not?
            boolean isRadioButtonDisplayed = radioButton.isDisplayed();
            System.out.println("Radio Button Displayed: " + isRadioButtonDisplayed);

            // Verify if the Radio Button is enabled or not?
            boolean isRadioButtonEnabled = radioButton.isEnabled();
            System.out.println("Radio Button Enabled: " + isRadioButtonEnabled);

            // Verify if the Radio Button is Selected or not?
            boolean isRadioButtonSelected = radioButton.isSelected();
            System.out.println("Radio Button Selected: " + isRadioButtonSelected);

            // Step 1.4.8: Dropdown list
            Select dropdown = new Select(driver.findElement(By.id("dropdownId")));

            // Check the Dropdown box existence
            boolean isDropdownPresent = driver.findElements(By.id("dropdownId")).size() > 0;
            System.out.println("Dropdown Present: " + isDropdownPresent);

            // Check if the Drop down is enabled or not?
            boolean isDropdownEnabled = ((WebElement) dropdown).isEnabled();
            System.out.println("Dropdown Enabled: " + isDropdownEnabled);

            // Select an item
            dropdown.selectByVisibleText("Option 1");

            // Items Count
            int dropdownItemsCount = dropdown.getOptions().size();
            System.out.println("Dropdown Items Count: " + dropdownItemsCount);

            // Step 1.4.9: Web table /HTML table
            WebElement table = driver.findElement(By.id("tableId"));

            // Get cell value
            WebElement cell = table.findElement(By.xpath("//tr[2]/td[3]"));
            String cellValue = cell.getText();
            System.out.println("Cell Value: " + cellValue);

            // Rows Count
            int rowsCount = table.findElements(By.tagName("tr")).size();
            System.out.println("Table Rows Count: " + rowsCount);

            // Cells Count
            int cellsCount = table.findElements(By.tagName("td")).size();
            System.out.println("Table Cells Count: " + cellsCount);

            // Step 1.4.10: Frame
            driver.switchTo().frame("frameName");

            // Additional operations inside the frame

            // Switch back to Top window
            driver.switchTo().defaultContent();

            // Step 1.4.11: Switching between tabs in the same browser window
            driver.get("https://example.com");

            // Open a new tab using Ctrl + t
            driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");

            // Driver control automatically switches to the newly opened tab
            ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
            driver.switchTo().window(tabs.get(1));

            // Perform the required operations here.

            // Next switch back to the old tab using Ctrl + Tab. You need to keep pressing this unless you reach the desired tab.
            driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "\t");

            // Once the desired tab is reached, then perform the operations in that tab.
            driver.switchTo().window(tabs.get(0));

            // Step 1.4.12: Pushing the code to your GitHub repositories
            // Open your command prompt and navigate to the folder where you have created your files.
            // cd <folder path>

            // Initialize your repository
            
        }
        catch(Exception e)
        {
        	
        }
    }
}
