import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ElementLocator {

    public static void main(String[] args) {
       
        System.setProperty("webdriver.chrome.driver", "C:\\Mphasis FSD\\1.Phase -5\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");

      
        WebDriver driver = new ChromeDriver();

        
        driver.get("https://google.com");

        
       
        WebElement emailInput = driver.findElement(By.cssSelector("input#email"));
        emailInput.sendKeys("example@email.com");

        
        WebElement passwordInput = driver.findElement(By.cssSelector("input.inputtext"));
        passwordInput.sendKeys("password123");

        
        
        WebElement absoluteXPathElement = driver.findElement(By.xpath("html/body/div[1]/div[1]/div/h4[1]/b"));
        System.out.println(absoluteXPathElement.getText());

        
        WebElement relativeXPathElement = driver.findElement(By.xpath("//*[@class='relativexapath']"));
        System.out.println(relativeXPathElement.getText());

        
        // Close the WebDriver
        driver.quit();
    }
}
