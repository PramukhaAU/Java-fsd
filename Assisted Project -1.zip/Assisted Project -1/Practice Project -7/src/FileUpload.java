

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FileUpload {

	public static void main(String[] args) {
		String path = "C:\\Mphasis FSD\\1.Phase -5\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe";
        System.setProperty("webdriver.chrome.driver", path);

        WebDriver driver = new ChromeDriver();
        driver.get("https://nxtgenaiacademy.com/alertandpopup/");

        // Assume there is an element with an input type file for uploading a file
        WebElement fileInput = driver.findElement(By.id("fileInputId")); // Replace with the actual ID

        // Provide the path to the file you want to upload
        String filePath = "C:\\Users\\HP\\Desktop\\To Test.txt"; // Replace with the actual file path

        // Use the sendKeys method to set the file path in the input field
        fileInput.sendKeys(filePath);

        // Perform other actions or submit the form as needed

        // Wait for some time to see the result before closing the browser
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Close the browser
        driver.quit();

	}

}
